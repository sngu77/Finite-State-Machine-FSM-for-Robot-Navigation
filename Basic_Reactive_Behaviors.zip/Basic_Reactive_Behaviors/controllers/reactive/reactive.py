from controller import Robot

# Constants
time_step = 32  # Time step in milliseconds
proximity_threshold = 80  # Adjusted threshold for detecting an obstacle

# FSM States
FORWARD = "FORWARD"
TURN_180 = "TURN_180"
TURN_CLOCKWISE = "TURN_CLOCKWISE"
FOLLOW_WALL = "FOLLOW_WALL"
STOP = "STOP"

# Initialize Robot
robot = Robot()

# Helper functions
def set_motor_speed(left_speed, right_speed):
    left_motor.setVelocity(left_speed)
    right_motor.setVelocity(right_speed)

def initialize_motors():
    left_motor = robot.getDevice("left wheel motor")
    right_motor = robot.getDevice("right wheel motor")
    left_motor.setPosition(float("inf"))
    right_motor.setPosition(float("inf"))
    return left_motor, right_motor

def initialize_distance_sensors(sensor_names):
    distance_sensors = []
    for name in sensor_names:
        sensor = robot.getDevice(name)
        sensor.enable(time_step)
        distance_sensors.append(sensor)
    return distance_sensors

def control_loop(left_motor, right_motor, distance_sensors):
    # Initialize state
    state = FORWARD
    turn_counter = 0

    # Main control loop
    while robot.step(time_step) != -1:
        front_sensor = max(distance_sensors[0].getValue(), distance_sensors[1].getValue())
        left_sensor = distance_sensors[3].getValue()
        
        if state == FORWARD:
            set_motor_speed(5.0, 5.0)
            if front_sensor > proximity_threshold:
                state = TURN_180
                turn_counter = 0
        
        elif state == TURN_180:
            set_motor_speed(-5.0, 5.0)  # Rotate 180 degrees
            turn_counter += 1
            if turn_counter > 20:  # Adjust to complete 180-degree turn
                state = FORWARD
        
        elif state == TURN_CLOCKWISE:
            set_motor_speed(5.0, -5.0)  # Turn clockwise
            turn_counter += 1
            if left_sensor < proximity_threshold or turn_counter > 10:
                state = FOLLOW_WALL
        
        elif state == FOLLOW_WALL:
            set_motor_speed(5.0, 5.0)  # Move forward
            if left_sensor >= proximity_threshold:
                state = STOP
        
        elif state == STOP:
            set_motor_speed(0, 0)
            break

# Initialize motors and distance sensors
left_motor, right_motor = initialize_motors()
sensor_names = ["ps0", "ps1", "ps2", "ps5"]  # Front and left sensors
distance_sensors = initialize_distance_sensors(sensor_names)

# Run the control loop
control_loop(left_motor, right_motor, distance_sensors)